Assets For Personal Use
